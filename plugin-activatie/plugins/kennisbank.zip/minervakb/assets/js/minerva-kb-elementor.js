/**
 * Project: Minerva KB
 * Copyright: 2015-2020 @KonstruktStudio
 */
(function($) {
    'use strict';

    function init() {
        // TODO: for future use & global data array
    }

    $(document).ready(init);
})(jQuery);