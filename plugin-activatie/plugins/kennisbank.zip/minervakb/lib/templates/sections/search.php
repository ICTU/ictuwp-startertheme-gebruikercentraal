<?php
/**
 * Project: MinervaKB.
 * Copyright: 2015-2016 @KonstruktStudio
 */

MKB_TemplateHelper::render_search($section["settings"]); ?>